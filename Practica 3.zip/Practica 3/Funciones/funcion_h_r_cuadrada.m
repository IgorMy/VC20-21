function I2=funcion_h_r_cuadrada(I)

    I2 = uint8(sqrt(255*double(I)));
    
end