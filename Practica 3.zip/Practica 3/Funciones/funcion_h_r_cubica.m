function I3=funcion_h_r_cubica(I)

    I3 = uint8((255^2*double(I)).^(1/3));
    
end