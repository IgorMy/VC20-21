function I3=funcion_h_cubica(I)

    I3 = uint8((double(I).^3)/(255^2));
    
end