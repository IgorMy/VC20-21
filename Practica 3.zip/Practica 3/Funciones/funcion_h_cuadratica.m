function I2=funcion_h_cuadratica(I)

    I2 = uint8((double(I).^2)/255);
    
end