%% Limpieza inicial
clear, clc, close all;

%% Adicción de carpetas
addpath('Funciones');

%% Ejecución del programa

% Sin la ampliación
Nombre = "Test_12.jpg";
Numero_Objetos = 7;
Cadena = Funcion_Reconoce_Matricula(Nombre, Numero_Objetos);

% Con la ampliación
Nombre = "04.JPG";
Numero_Objetos = 7;
Cadena = Funcion_Reconoce_Matricula_con_ampliacion(Nombre, Numero_Objetos);
